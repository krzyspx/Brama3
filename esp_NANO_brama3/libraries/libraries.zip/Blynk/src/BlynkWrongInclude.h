/**
 * @file       BlynkWrongInclude.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jun 2016
 * @brief
 *
 */

#ifndef BlynkWrongInclude_h
#define BlynkWrongInclude_h

#error Please include a board-specific header file (see examples)

#endif
